# Portable AI 软件公司 CTO

公开安装源：<https://github.com/aldolomascolo-max/cto-company-installer>

这个小包用于“新电脑只安装了 Codex”的情况。它会安装：

- 本地 `cto-company` CTO 插件及五个工程专项技能；
- 官方 BMAD Method 和 Toolbox 插件；
- 全局 CTO 入口规则；
- 可选项目级 `.cto-company` 状态、岗位 roster 和事件日志。

## 新电脑一键安装

### macOS

从 GitHub 页面下载仓库 ZIP，解压后双击根目录的 `install.command`。如果只下载了本目录的安装包，也可以双击这里的 `install.command`。系统会自动检查环境、安装 CTO 和 BMAD；完成后完全退出并重新打开 Codex。

### Windows

解压后双击 `install.bat`，按窗口提示完成安装。

### Codex 对话框

如果不方便双击，直接在 Codex 新任务中粘贴仓库根目录的 `START-HERE.txt`。如果需要手动运行，把 ZIP 下载并解压，然后在解压目录运行：

```bash
python3 install.py --project "/你的项目目录"
```

安装脚本会先检查 Python、Git、网络、写入权限和 Codex CLI；macOS 会自动寻找 Codex 应用包里的 CLI。如果有 npx，还会安装可选的 Sleek 移动设计技能；Sleek API key 只应保存在本机环境变量中。完成后完全退出并重新打开 Codex，再新开任务，粘贴 `restore-prompt.txt` 的内容。

CTO 会按产品需要按需启用 Python 自动化、BI、数据工程、LLM 应用工程和云计算/DevOps 能力；未安装的专用技能会记录实际回退方案，不会假装已经调用。

如果不指定 `--project`，只安装全局 CTO 和 BMAD，不修改任何项目目录。

这个包不包含 API key、OAuth 登录、服务器密码、支付凭据或第三方账号。它也不创建后台常驻进程；Codex 关闭后，项目状态保存在 `.cto-company/`，下次任务从那里恢复。

## 验证

```bash
codex plugin list --json
```

应看到 `cto-company@personal`、`bmad-method@bmad` 和 `bmad-toolbox@bmad`。然后在新任务里让 CTO 先做环境自检，不要直接开始业务开发。
