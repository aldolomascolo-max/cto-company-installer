---
name: bi-analytics
description: Define and verify product metrics, SQL or spreadsheet analysis, dashboards, and operational reports when a product needs BI, growth, revenue, or user-behavior insight. Do not invent metrics from screenshots or unverified data.
---

# Bi Analytics

Activate only when the capability plan marks BI or reporting as relevant.

1. Start with decisions the metric must support. Define metric name, owner, grain, time zone,
   filters, inclusion/exclusion rules, null and duplicate handling, refresh expectation and
   privacy boundary before writing a query or chart.
2. Trace every number to a source table/event/API and record the query or transformation. Reuse
   the project's database and spreadsheet/visualization tools; do not add a warehouse for a
   small product without a measured need.
3. Check joins, time windows, permissions, late events, retries and test fixtures. Label sample
   or simulated data clearly. Avoid exposing sensitive user-level data in reports.
4. Verify a representative result against a hand-check or invariant and capture the report,
   query, timestamp and evidence path. Separate implemented dashboard, validated metric and
   unverified business interpretation.
