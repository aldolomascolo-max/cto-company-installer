#!/usr/bin/env python3
"""Create the small, durable state surface used by cto-company.

This only writes inside the selected project: `.cto-company/` and a marked
section in the project's AGENTS.md. It does not install dependencies, run
commands, start services, or overwrite existing project instructions.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import sys


MARKER_START = "<!-- BEGIN cto-company project -->"
MARKER_END = "<!-- END cto-company project -->"

PROJECT_RULES = f"""{MARKER_START}
## AI software company project state

Use the installed `cto-company:cto-company` skill as the single product lead for
complete-product work. Read `.cto-company/state.md` and `.cto-company/team.md`
before planning. Keep the state current after material decisions, verification,
handoffs, blockers, and resumable next actions. Do not call a prototype or an
unverified preview complete. Preserve this project's existing instructions,
secrets, scope, and approval boundaries.
{MARKER_END}
"""

STATE_TEMPLATE = """# CTO project state

status: initialized
last_updated: {timestamp}
project: {project}

## Product intent

<!-- CTO records the user's agreed product intent and explicit non-goals here. -->

## Current phase

intake

## Decisions

<!-- One decision per bullet: date — decision — reason — approver. -->

## Acceptance and evidence

<!-- Link or path to work/cto/page-state-matrix.md, acceptance commands, screenshots and reports. -->

## CTO artifacts

- `work/cto/intake.md`
- `work/cto/product-map.md`
- `work/cto/page-state-matrix.md`
- `work/cto/interaction-contract.md`
- `work/cto/data-flow.md`
- `work/cto/capability-plan.md`
- `work/cto/acceptance.template.json`

## Active work

<!-- task | owner | status | dependency | evidence -->

## Blockers and user decisions

<!-- Keep only unresolved items that really require the user or external access. -->

## Next resumable action

Read this file, verify current artifacts, then continue from the active work list.
"""

TEAM_TEMPLATE = """# CTO project team roster

The CTO is the single accountable lead. Roles are activated only when the product
needs them; a role is a responsibility and evidence contract, not a claim of human
employment history.

| Role | Responsibility | Required evidence |
|---|---|---|
| Project manager (PM) | Delivery plan, milestones, resources, risks, issues and acceptance | Charter, milestone plan, risk/issues log and closeout |
| Product owner/manager (PO) | Users, product value, roadmap, priority and feedback | Product brief/PRD, prioritized backlog and product acceptance |
| Product lead | Intent, scope, journeys, acceptance | Approved product map and gaps |
| Research/knowledge | Sources, references, version/rights checks and reusable evidence | Dated source ledger and applicability notes |
| Architect | Boundaries, contracts, dependencies | Architecture decisions and interface checks |
| UX designer | User goals, journey strategy, research assumptions, information architecture | Experience map, journey decisions, UX acceptance |
| Interaction designer (IxD) | Functional logic, page flow, control behavior, transitions and states | Interaction specification and flow/state checks |
| UI designer | Visual system, layout, typography, color, icons and assets | Screenshots, tokens, asset provenance |
| Frontend | Responsive user journeys and accessibility | Browser checks, console/network evidence |
| Backend/API | Business behavior, validation, failures | API/integration checks and durable state |
| Data/reliability | Constraints, concurrency, migration/recovery | Invariant and recovery evidence |
| Security | Trust boundaries, auth, secrets, tenant isolation | Findings and verified fixes |
| QA/reviewer | Independent completeness and regression review | Fresh review, findings, retest |
| Release/SRE | Build, health, observability, rollback | Target-specific release evidence |
| Documentation/support/growth | Onboarding, help, support and growth only when relevant | Current runbook, help content and measured outcomes |
| Python automation (optional) | Batch jobs, imports/exports, test and release scripts | Reproducible script and failure checks |
| BI/analytics (optional) | Metrics, dashboards and operational reporting | Metric definitions, queries and validated report |
| Data engineering (optional) | ETL/ELT, event flows, lineage and data quality | Replay, quality and recovery evidence |
| LLM application engineering (optional) | Model, retrieval, tool-use and evaluation flows | Real traces, evals, safety and cost/latency evidence |
| Cloud/DevOps (optional) | Environments, deployment, observability and recovery | Build, health, rollback and recovery evidence |

The CTO assigns exact ownership, selected skills, tools and checks per task. Workers
must report changes, commands/results, decisions and remaining gaps. The roster is
stable; active assignments belong in `state.md`.
"""

ARTIFACT_TEMPLATES = {
    "intake.md": """# CTO intake\n\n## Facts and sources\n\n- Project path:\n- Runtime entry points:\n- Source/reference locations:\n- Observed commands and environments:\n\n## Product type and users\n\n- Product form:\n- Users and jobs:\n- Supported platforms:\n\n## Unknowns and blockers\n\n- [ ]\n\n## Capability and permission check\n\n| Capability | Installed | Loaded | Called successfully | Project verified | Evidence/gap |\n|---|---|---|---|---|---|\n|\n\n## Source-of-truth decisions\n\n-\n""",
    "product-map.md": """# Product map\n\n## Goal and non-goals\n\n- Goal:\n- Non-goals:\n\n## Users and journeys\n\n| ID | User/job | Entry | Steps | Durable result | Visible confirmation | Recovery | Status |\n|---|---|---|---|---|---|---|---|\n|\n\n## Supporting pages/services\n\n| Area | Required/useful/N/A | Reason | Evidence |\n|---|---|---|---|\n|\n\n## Decisions and assumptions\n\n-\n""",
    "page-state-matrix.md": """# Page and state matrix\n\n| Page/flow | Control/action | Initial | Loading | Validation | Success | Empty | Error | Permission/session | Retry/cancel | Responsive/accessibility | Evidence |\n|---|---|---|---|---|---|---|---|---|---|---|---|\n|\n""",
    "interaction-contract.md": """# Interaction contract\n\nFor every required control record intent, enabled rule, feedback, duplicate-input\nbehavior, keyboard/focus behavior, copy and recovery.\n\n| Flow/control | Intent | Trigger | Feedback/timing | Failure/recovery | Copy | Accessibility | Evidence |\n|---|---|---|---|---|---|---|---|\n|\n""",
    "data-flow.md": """# Data flow and invariants\n\n| User action | API/service | Validation/auth | External dependency | Durable write | Visible result | Retry/idempotency | Evidence |\n|---|---|---|---|---|---|---|---|\n|\n\n## Invariants\n\n-\n\n## Recovery\n\n- Refresh:\n- Restart:\n- Connection loss:\n- Migration/rollback:\n""",
    "capability-plan.md": """# On-demand capability plan\n\nDefault policy: activate only the capabilities required or useful for this product.\nResolve each candidate against the current Codex catalog before dispatch. Missing\noptional capabilities are recorded as deferred/N/A; missing required capabilities\nblock the affected gate or use one documented fallback.\n\n| Capability pack | Why this product needs it | Candidate skills/tools | Resolved | Evidence or fallback | Status |\n|---|---|---|---|---|---|\n| Core product/engineering | | | | | |\n| Python automation | | | | | N/A |\n| BI analytics | | | | | N/A |\n| Data engineering | | | | | N/A |\n| LLM application engineering | | | | | N/A |\n| Cloud/DevOps | | | | | N/A |\n\n## Activation decisions\n\n-\n""",
    "acceptance.template.json": """{\n  \"schema_version\": 1,\n  \"note\": \"Replace these placeholders with real project commands before running check_delivery.py. An empty template is not evidence.\",\n  \"checks\": []\n}\n""",
}


def atomic_write(path: Path, content: str) -> None:
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.write_text(content, encoding="utf-8")
    temporary.replace(path)


def append_rules(path: Path) -> bool:
    existing = path.read_text(encoding="utf-8") if path.exists() else ""
    if MARKER_START in existing or MARKER_END in existing:
        if MARKER_START not in existing or MARKER_END not in existing:
            raise ValueError("AGENTS.md has an incomplete cto-company project block")
        return False
    separator = "\n" if existing and not existing.endswith("\n") else ""
    atomic_write(path, existing + separator + "\n" + PROJECT_RULES)
    return True


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", required=True, type=Path)
    parser.add_argument("--event", help="Append one durable event to events.ndjson")
    parser.add_argument("--owner", default="cto", help="Owner for --event")
    args = parser.parse_args()

    project = args.project.expanduser()
    if not project.is_absolute() or not project.is_dir():
        parser.error("--project must be an existing absolute directory")
    project = project.resolve()
    state_dir = project / ".cto-company"
    state_dir.mkdir(exist_ok=True)
    work_dir = project / "work" / "cto"
    work_dir.mkdir(parents=True, exist_ok=True)
    state = state_dir / "state.md"
    team = state_dir / "team.md"
    events = state_dir / "events.ndjson"
    timestamp = datetime.now(timezone.utc).isoformat()
    created = []
    if not state.exists():
        atomic_write(state, STATE_TEMPLATE.format(timestamp=timestamp, project=project))
        created.append(str(state))
    if not team.exists():
        atomic_write(team, TEAM_TEMPLATE)
        created.append(str(team))
    if not events.exists():
        atomic_write(events, "")
        created.append(str(events))
    artifacts_created = []
    for name, template in ARTIFACT_TEMPLATES.items():
        path = work_dir / name
        if not path.exists():
            atomic_write(path, template)
            artifacts_created.append(str(path))
    rules_added = append_rules(project / "AGENTS.md")
    if args.event:
        with events.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps({"timestamp": timestamp, "owner": args.owner, "event": args.event}, ensure_ascii=False) + "\n")
    bmad_ready = (project / "_bmad" / "scripts" / "render_skill.py").is_file()
    print(json.dumps({
        "project": str(project),
        "state_dir": str(state_dir),
        "created": created,
        "artifacts_created": artifacts_created,
        "agents_rules_added": rules_added,
        "bmad_runtime": "ready" if bmad_ready else "setup-required",
        "event_recorded": bool(args.event),
    }, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError) as error:
        print(f"bootstrap_project: {error}", file=sys.stderr)
        raise SystemExit(2)
