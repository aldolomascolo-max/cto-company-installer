---
name: python-automation
description: Create and verify small, reproducible Python automation for imports, exports, asset processing, test helpers, batch jobs, or release tasks when the product actually needs it. Do not activate for ordinary application code that does not need Python.
---

# Python Automation

Use this skill only when the CTO capability plan marks Python automation as required or useful.

1. Inspect existing scripts, runtime versions, dependency policy, input/output formats and
   project conventions before adding anything. Prefer Python's standard library and existing
   runners; do not add a framework for a short script.
2. Define a small command contract: arguments, input validation, output format, exit codes,
   dry-run behavior for destructive operations, retry/timeout behavior and where logs go.
3. Keep runs repeatable and safe to resume. Do not print secrets or personal data. Use atomic
   writes, bounded concurrency and explicit encoding/time-zone handling when relevant.
4. Add the smallest meaningful self-check or project-native test. Run it with a representative
   fixture and record command, result and known limits in the CTO evidence.
5. Return changed files, usage command, sample result, verification evidence and any missing
   Python package or external credential. A script that was written but not executed is not
   complete.
