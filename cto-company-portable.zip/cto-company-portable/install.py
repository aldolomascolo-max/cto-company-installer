#!/usr/bin/env python3
"""Install the local CTO plugin and the official BMAD plugins on a fresh Codex host."""

from __future__ import annotations

import argparse
import json
import os
import platform
from pathlib import Path
import shutil
import subprocess
import sys
from typing import Optional
import urllib.request


MARKER_START = "<!-- BEGIN cto-company -->"
MARKER_END = "<!-- END cto-company -->"
ROOT = Path(__file__).resolve().parent
PLUGIN_SOURCE = ROOT / "plugin"

GLOBAL_RULES = f"""{MARKER_START}
## Complete-product CTO workflow

For requests to build a complete app, website, SaaS, platform, game, or software product, use the installed `cto-company:cto-company` skill as the single top-level workflow. The user's feature list is not exhaustive: infer necessary pages, journeys, states, assets, backend/data support, tests, security, performance, operations and delivery evidence. Keep isolated fixes and research within their requested scope.

The CTO owns product completeness, dispatch, integration, independent review and repair. Use PM, PO, UX, Interaction Design, UI, frontend/game, backend/API, data, security, QA, performance and release roles when applicable. Persist project state in `.cto-company/`; never claim a prototype or unverified preview is complete. Preserve existing project instructions and authorization boundaries.
{MARKER_END}
"""


def run(args: list[str]) -> int:
    print("$", " ".join(args))
    return subprocess.run(args, check=False).returncode


def find_codex_cli() -> Optional[list[str]]:
    """Find the Codex CLI even when the desktop app was not added to PATH."""
    configured = os.environ.get("CODEX_CLI")
    candidates = [Path(configured).expanduser()] if configured else []
    on_path = shutil.which("codex")
    if on_path:
        candidates.append(Path(on_path))

    if platform.system() == "Darwin":
        for app_name in ("ChatGPT.app", "Codex.app"):
            candidates.extend(
                [
                    Path("/Applications") / app_name / "Contents/Resources/codex",
                    Path.home() / "Applications" / app_name / "Contents/Resources/codex",
                ]
            )
    elif platform.system() == "Windows":
        local_app_data = os.environ.get("LOCALAPPDATA")
        if local_app_data:
            candidates.extend(
                [
                    Path(local_app_data) / "Programs/Codex/codex.exe",
                    Path(local_app_data) / "Programs/ChatGPT/codex.exe",
                ]
            )

    for candidate in candidates:
        if candidate.is_file() and os.access(candidate, os.X_OK):
            return [str(candidate)]
    return None


def check_network() -> tuple[bool, str]:
    try:
        with urllib.request.urlopen("https://github.com", timeout=8) as response:
            return True, f"HTTP {response.status}"
    except Exception as exc:  # network errors vary by platform and proxy
        return False, str(exc)


def check_writable(path: Path) -> tuple[bool, str]:
    try:
        path.mkdir(parents=True, exist_ok=True)
        probe = path / ".cto-company-write-check"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
        return True, str(path)
    except Exception as exc:
        return False, f"{path}: {exc}"


def install_local_plugin(home: Path) -> Path:
    if not PLUGIN_SOURCE.is_dir():
        raise RuntimeError(f"missing bundled plugin: {PLUGIN_SOURCE}")
    destination = home / ".agents" / "plugins" / "plugins" / "cto-company"
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(PLUGIN_SOURCE, destination, dirs_exist_ok=True)
    shortcut = home / "plugins" / "cto-company"
    shortcut.parent.mkdir(parents=True, exist_ok=True)
    if shortcut.exists() or shortcut.is_symlink():
        if not shortcut.is_symlink() or shortcut.resolve() != destination.resolve():
            raise RuntimeError(f"existing path is not the expected CTO shortcut: {shortcut}")
    else:
        shortcut.symlink_to(destination, target_is_directory=True)
    return destination


def install_personal_marketplace(home: Path) -> Path:
    path = home / ".agents" / "plugins" / "marketplace.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {
        "name": "personal", "interface": {"displayName": "Personal"}, "plugins": []
    }
    plugins = payload.setdefault("plugins", [])
    entry = {
        "name": "cto-company",
        "source": {"source": "local", "path": "./plugins/cto-company"},
        "policy": {"installation": "AVAILABLE", "authentication": "ON_INSTALL"},
        "category": "Productivity",
    }
    plugins[:] = [p for p in plugins if not isinstance(p, dict) or p.get("name") != "cto-company"]
    plugins.append(entry)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return path


def append_global_rules(codex_home: Path) -> Path:
    path = codex_home / "AGENTS.md"
    existing = path.read_text(encoding="utf-8") if path.exists() else ""
    if MARKER_START not in existing:
        separator = "\n" if not existing or existing.endswith("\n") else "\n\n"
        path.write_text(existing + separator + GLOBAL_RULES, encoding="utf-8")
    return path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", type=Path, help="Optional project to bootstrap after installation")
    args = parser.parse_args()
    codex_home = Path(os.environ.get("CODEX_HOME", Path.home() / ".codex")).expanduser()

    codex_cli = find_codex_cli()
    git_cli = shutil.which("git")
    network_ok, network_detail = check_network()
    home_ok, home_detail = check_writable(Path.home())
    codex_home_ok, codex_home_detail = check_writable(codex_home)
    preflight = {
        "python3": sys.executable,
        "git": git_cli or "missing",
        "codex_cli": codex_cli[0] if codex_cli else "missing",
        "network": network_detail if network_ok else f"unavailable: {network_detail}",
        "home_writable": home_detail if home_ok else f"unwritable: {home_detail}",
        "codex_home_writable": codex_home_detail if codex_home_ok else f"unwritable: {codex_home_detail}",
    }
    print(json.dumps({"preflight": preflight}, ensure_ascii=False))
    if not codex_cli or not git_cli or not network_ok or not home_ok or not codex_home_ok:
        print(
            "环境检查未通过。请先安装/启用 Git、网络或 Codex CLI；"
            "也可以设置 CODEX_CLI 指向 Codex 可执行文件，然后重新运行。",
            file=sys.stderr,
        )
        return 2

    destination = install_local_plugin(Path.home())
    marketplace = install_personal_marketplace(Path.home())
    agents = append_global_rules(codex_home)
    print(json.dumps({"plugin_source": str(destination), "marketplace": str(marketplace), "global_rules": str(agents)}, ensure_ascii=False))
    if run(codex_cli + ["plugin", "marketplace", "add", "bmad-code-org/bmad-plugins"]) not in (0, 1):
        print("BMAD marketplace command failed; rerun it after checking network access.", file=sys.stderr)
    for plugin in ("bmad-method@bmad", "bmad-toolbox@bmad", "cto-company@personal"):
        if run(codex_cli + ["plugin", "add", plugin]) != 0:
            print(f"Plugin install failed: {plugin}", file=sys.stderr)
    npx_cli = shutil.which("npx")
    if npx_cli:
        if run(
            [
                npx_cli,
                "--yes",
                "skills",
                "add",
                "sleekdotdesign/agent-skills",
                "-s",
                "sleek-design-mobile-apps",
                "--global",
                "--agent",
                "codex",
                "--yes",
            ]
        ) != 0:
            print("Optional Sleek design skill install failed; continue without it.", file=sys.stderr)
    else:
        print("Optional Sleek design skill skipped: npx is not available.")
    if args.project:
        project = args.project.expanduser().resolve()
        if not project.is_dir():
            raise SystemExit(f"project does not exist: {project}")
        bootstrap = destination / "skills" / "cto-company" / "scripts" / "bootstrap_project.py"
        run([sys.executable, str(bootstrap), "--project", str(project), "--event", "Portable CTO installation initialized this project."])
    print("Restart Codex, open a new task, and paste restore-prompt.txt.\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
