# Third-party skill sources

The following complete skill directories are copied from wshobson/agents at commit a30778f8c4e6b0a87567941b7cca4f534bf642b6 (MIT; see LICENSE.wshobson). Local change: corrected the relative advanced-strategies.md link inside deployment-pipeline-design/references/details.md; other upstream content is unchanged.

- plugins/backend-development/skills/api-design-principles
- plugins/database-design/skills/postgresql-table-design
- plugins/developer-essentials/skills/e2e-testing-patterns
- plugins/ui-design/skills/accessibility-compliance
- plugins/cicd-automation/skills/deployment-pipeline-design

Source: https://github.com/wshobson/agents/tree/a30778f8c4e6b0a87567941b7cca4f534bf642b6

These are reference skills; example code, dependency names, helper scripts and CI notifications are not installed or authorized automatically. The cto-company skill, references and check runner are local integration work. Existing BMAD, Astral, design, browser, image generation, hosting and security skills remain separately installed; they are not bundled here.
