---
name: cloud-devops
description: Design and verify production cloud and DevOps delivery including environments, CI/CD, observability, health checks, rollback, backups, and recovery when an online product needs it.
---

# Cloud Devops

This is a workflow-only wrapper, not a cloud provider or deployment service. Use the verified target-specific deployment skills and CLIs first.

Activate when the capability plan identifies online production delivery, multiple environments,
containers, scaling, zero-downtime, or recovery requirements.

1. Identify the actual target provider and runtime first. Separate local, preview, staging and
   production configuration; keep secrets out of code and state the account/permission needed.
2. Reuse the project's build and deployment path. Define reproducible build, configuration,
   migrations, health/readiness checks, logs/metrics, alert conditions and release gates.
3. Design rollback and recovery before rollout: compatible migrations, backup/restore, failed
   deploy handling, dependency outage behavior and a clear operator runbook. Use provider skills
   only when they match the real target; do not claim AWS/GCP/Azure work from generic advice.
4. Verify in the target or an explicitly named equivalent environment. Record commands, health
   results, artifacts, observed limits and remaining credentials. Do not publish or change
   production without the user's authorization.
