# Delivery evidence

Cover essential agreed journeys with proportional checks. Use existing CI when it
supplies equivalent evidence. No tests, skipped checks or a preview page do not prove
complete production acceptance.

## Local automated commands

Use Python 3.9+ and create `work/cto/acceptance.json` when no equivalent runner exists.
This is trusted local command input: inspect every command and apply normal
authorization. The runner does not sandbox commands or grant permission. Keep
credentials out of arguments, manifests and retained output.

```json
{
  "schema_version": 1,
  "checks": [
    {"id": "build", "argv": ["npm", "run", "build"], "timeout_seconds": 300},
    {"id": "journeys", "argv": ["npm", "run", "test:e2e"], "timeout_seconds": 300}
  ]
}
```

Substitute commands observed in the actual repository; these names are examples.
IDs must be unique, argv nonempty, cwd optional and inside the project, timeout a
positive integer no greater than 3600 seconds. Use the resolved installed skill path:

```text
python3 <skill-dir>/scripts/check_delivery.py --project <project-dir> --manifest <project-dir>/work/cto/acceptance.json --output <project-dir>/work/cto/results.json
```

The runner records manifest hash, invocation, elapsed time, exit status and bounded
output. Invalid/empty manifests fail before execution. Exit 0 means a nonempty set of
automated checks passed; exit 1 means execution failure; exit 2 means invalid input or
report-output failure. On exit 2 an existing report may be from an older run: ignore
it and resolve the CLI error. Cancellation exits 130 (SIGINT) or 143 (SIGTERM), stops
the active check and does not run subsequent checks; ignore previous reports then too.
POSIX timeout/cancellation cleanup targets the process group; deliberately detached
processes need external isolation. A trivial successful command is not meaningful acceptance:
the reviewer must inspect whether checks actually exercise requirements.

Results become stale when relevant source/configuration changes; rerun affected checks
on current artifacts. The manifest hash identifies the configuration, not a source
revision. Do not treat its success as review, visual acceptance or deployment.

## Additional evidence

- Every required page/journey/service is implemented and linked to verification, or
  visibly blocked.
- Inspect real rendered pages, viewports/keyboard, loading/empty/errors, actual assets
  and console/network results.
- Trace user action -> API -> external adapter when applicable -> durable record ->
  visible confirmation, including refresh/restart and failure recovery.
- A fresh reviewer inspects current changes and checks fixes. A self-authored “review
  passed” file is not independent review.
- Verify startup/configuration, target health, migration and rollback/recovery
  separately. Do not call a local build deployed.

## Reliability and data checks

Agree workload, then measure latency percentiles, throughput, failures and resources
using actual load/profiling tools. Record the environment and load; never invent
capacity numbers. Cover concurrency, duplicate requests/messages, retries, timeouts,
interruption, connection loss and restart where they affect data. Test business
invariants, e.g. no double debit or prohibited negative stock, not only happy paths.

For multi-tenancy, check ownership across APIs, cache, queues, files and exports.
Check useful logs/metrics, request correlation, bounded label cardinality, meaningful
alerts and appropriate backup/restore/rollback. Do not introduce Kubernetes, tracing
stacks or tenancy merely to satisfy the checklist.

## Rework and closeout

Record finding -> owner -> fix -> rerun evidence -> reviewer disposition in the
existing plan/issues. Essential failures or untested requirements block complete
delivery. After three unsuccessful attempts on the same finding, change approach or
escalate with evidence; never hide, quietly waive or loop indefinitely. Record
user-approved scope changes explicitly.

Handoff: what works, how to use it, actual checks, independent review result and gaps.
Before handoff, update `.cto-company/state.md` and append the handoff event to
`.cto-company/events.ndjson`. Preserve progress if tools/context/account limits/access
stop work. Installing this workflow alone is not proof that a future product is
production-ready.
