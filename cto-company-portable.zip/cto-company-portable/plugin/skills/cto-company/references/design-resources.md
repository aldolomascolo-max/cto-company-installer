# UI/UX design reference library

Use these as searchable inspiration and benchmarking sources when the project
needs interface, interaction, motion, brand, typography, icon or design-system
work. They are references, not automatic requirements and not a license to copy
protected assets or content.

| Use | Source |
|---|---|
| Curated design collections | https://curations.supply/ |
| Landing-page inspiration | https://landing.love/ |
| SaaS page and section patterns | https://saaspo.com/ |
| AI-assisted design creation | https://sleek.design/ |
| Fonts | https://uncut.wtf/ |
| Motion and interaction examples | https://60fps.design/ |
| Mobile product flows | https://mobbin.com/ |
| Brand identity references | https://rebrand.gallery/ |
| Icons | https://hugeicons.com/ |
| Component and design-system patterns | https://component.gallery/ |

## How to use the library

1. Select sources that match the product type, audience and approved visual direction.
2. Record the source, access date, what was borrowed, why it fits and how it was adapted.
3. Treat screenshots and examples as inspiration or evidence of a pattern; do not
   claim that viewing an example means the product implements it.
4. Check asset licenses, attribution, account requirements and paid restrictions
   before using fonts, icons, images, code or templates in a deliverable.
5. If a source is unavailable, gated or unsuitable, report that fact and continue
   with a licensed or native alternative.
