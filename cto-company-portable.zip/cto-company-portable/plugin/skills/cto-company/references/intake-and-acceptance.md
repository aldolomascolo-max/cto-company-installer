# Universal product intake and acceptance

Use this workflow for any new product or substantial feature. It is the generic
execution contract; it does not contain a project's business rules.

## Intake evidence

Before implementation, inspect the current workspace and supplied references. Record
what is observed, what is inferred, what is missing and what is not applicable in
`work/cto/intake.md`:

- project shape and runtime entry points;
- source, generated output, backups and stale reports;
- users, core jobs, platforms and supported devices;
- existing routes, APIs, data stores, jobs and external services;
- available skills, tools, credentials and permission limits;
- references, rights, versions and capture dates;
- risks, unknowns and decisions that truly require the user.

Do not treat a screenshot, build artifact, old report or agent summary as proof of a
working feature. Do not import another project's business rules. If the workspace is
not the intended project, stop and identify the mismatch.

## Required artifacts

Create or update these files before implementation when the scope is multi-phase:

| Artifact | Purpose |
|---|---|
| `work/cto/intake.md` | Facts, sources, unknowns, permissions and project type |
| `work/cto/product-map.md` | Users, journeys, scope, pages/services, data and non-goals |
| `work/cto/page-state-matrix.md` | Every required page, control, state, copy and recovery path |
| `work/cto/interaction-contract.md` | Navigation, input behavior, feedback, timing and accessibility |
| `work/cto/data-flow.md` | User action → API/service → durable data → visible result |
| `work/cto/acceptance.template.json` | Candidate build, test, browser, security and release checks |
| `.cto-company/state.md` | Decisions, owners, evidence, gaps and next resumable action |

Small changes may record a compact version in `.cto-company/state.md`; mark unused
artifacts N/A with a reason rather than creating empty process files.

## Full-dimension interaction check

For each required journey, record:

`entry → action → loading → validation → success → empty → error → permission/session
expiry → retry/cancel → refresh/restart → durable result → visible confirmation`.

For each button or control, answer what it does, when it is enabled, what feedback it
gives, what happens on duplicate input, and how the user recovers. Cover touch,
keyboard/focus, responsive layout, copy clarity, localization, reduced motion and
accessibility when relevant.

## Decision and handoff rules

- Resolve routine technical and visual choices using evidence and record assumptions.
- Ask only about choices that change the product goal, core rule, legal/financial risk,
  material cost, external authorization or release scope.
- Each worker packet names its objective, owned files, required skills, tools,
  dependencies, acceptance checks and return format.
- The CTO integrates the current workspace and reruns affected checks after merging.

## Completion states

Every acceptance entry is one of `PASS`, `FAIL`, `UNVERIFIED`, `BLOCKED` or `N/A`.
Required entries marked `UNVERIFIED` or `BLOCKED` prevent a complete-delivery claim.
Separate implemented, automated checks passed, independent review passed,
release-ready, deployed and clean-environment verified.
