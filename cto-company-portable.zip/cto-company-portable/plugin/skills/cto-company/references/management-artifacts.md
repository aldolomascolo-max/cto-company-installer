# Product and project management evidence

Use for multi-phase products, client delivery, or work with meaningful scope,
dependencies, cost, risk or release coordination. Do not generate every document for
a tiny fix; mark an artifact `N/A` with a reason when it has no decision value.

## PM — delivery ownership

Maintain a compact project charter with objective, boundaries, assumptions, budget or
resource constraints and success criteria. Keep a milestone plan with dependencies,
owners and acceptance gates. Track risks, issues, decisions, external dependencies
and required user decisions. Record material scope changes and their effect on time,
cost, quality and risk. Before handoff, record release readiness, acceptance evidence,
known gaps, rollback/recovery path and a short retrospective.

The source of truth is `.cto-company/state.md` plus its append-only
`.cto-company/events.ndjson`; use `work/cto/plan.md` for detail when needed. A table
of tasks without owners, dependencies, evidence and next actions is not a project
plan.

## PO — product ownership

For a new product or material feature, record the target users, problem, user journeys,
desired outcome, non-goals, competitor/reference observations, priority rationale and
acceptance criteria. Keep a lightweight roadmap or prioritized backlog. Define the
product metrics or observable signals that will tell whether the feature works, and
capture post-release feedback as future decisions. Close a requirement only after
product acceptance and technical evidence agree.

User research can be lightweight: a first-party reference review, existing user
feedback, a small interview set, or an explicitly recorded assumption when research
is unavailable. Never invent customer evidence. Product training or handoff notes are
needed when another operator or customer must run the result.

## Review gates

PM and PO artifacts are inputs to architecture, UX/IxD/UI, implementation, QA and
release. They do not authorize production changes, payments, external messages or
deployment. The CTO remains accountable for routing and integration; PM/PO findings
must be represented in the implementation plan and acceptance map.
