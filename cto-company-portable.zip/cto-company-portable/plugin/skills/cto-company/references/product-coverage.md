# Product completeness, proportional to the product

Use at intake and final integration. This is a discovery aid, not permission to add
every feature. Start from user intent and existing behavior; mark irrelevant entries
N/A with a reason.

| Area | Infer and check when relevant |
|---|---|
| Product | Target users, job to complete, core journeys, platforms, competitor gaps and boundaries |
| Identity/access | Whether accounts are needed; login/register/logout/recovery, verification/invitations/roles only as needed, session expiry and permission feedback |
| Pages/navigation | Entry, main workspace, detail/create/edit, search/filter/pagination where needed, account/settings/help, back/deep links/404 |
| Business support | History/status, cancellation/confirmation, imports/exports, notifications, admin/moderation only where required |
| States | Initial/loading/empty/populated/invalid/saving/success/error/forbidden/expired/disconnected; retry/double-submit and accessible feedback |
| Visuals/assets | Layout, typography, tokens, icons, useful images, copy, app identity, rights/provenance, no accidental placeholders |
| Accessibility/devices | Keyboard/focus/labels/contrast/reduced motion, agreed viewport and mobile behavior |
| APIs/integrations | Contracts, validation, errors, auth, timeouts/retries/idempotency, rate limits as needed, unavailable-provider behavior |
| Durable data | Schema/constraints, transactions/precision/concurrency, migrations, history/audit, seed/setup and recovery |
| Tenants | Only if multi-tenant: ownership in reads/writes, cache, jobs, files/exports and admin access |
| Security | Trust boundaries, secrets, permissions, dependencies and abuse paths relevant to the app |
| Performance/operations | Agreed workload and latency/throughput, measured bottlenecks, logs/metrics/correlation/alerts proportional to needs |
| Recovery/delivery | Failure/restart/reconnect, backups when needed, migration, build/start/deploy/health/rollback and user documentation |

For each required journey record entry -> steps -> durable result -> visible
confirmation -> relevant failure/recovery -> verification. Check across pages, roles
and services, not only each module. Confirm the product map, visual direction and
delivery target without asking the user to approve every routine detail.

Examples:
- Inventory software implies item/stock workflows, navigation, states and storage;
  accounts, audit, roles and imports depend on actual use.
- A login bug remains a login-flow repair, not a new billing system or whole redesign.
- An offline personal calculator does not imply accounts or a cloud database.
- Exchange futures require derivatives/ledger/risk rules; a smart-contract skill
  alone does not cover them.

For named competitors, inspect current first-party behavior/docs and record a scoped
gap map: covered / intentionally reduced / missing / unverified. Similar screenshots
do not prove parity. Use domain expertise for high-consequence business rules.
