# Universal quality gates

These gates apply to complete-product work. They are evidence gates, not role names.

1. **Intake gate** — current project, source of truth, scope, users, references,
   permissions and unknowns are recorded.
2. **Product gate** — product map, non-goals, journeys, page/state matrix and key
   decisions are approved or explicitly marked assumed.
3. **Architecture gate** — contracts, data ownership, error behavior, security
   boundaries, dependencies and recovery decisions are recorded.
4. **Design gate** — UX, interaction and UI contracts agree; every required journey
   has loading/empty/error/permission/retry behavior and usable copy.
5. **Implementation gate** — real APIs, durable data, assets and user actions are
   connected; mocks and test data are labelled.
6. **Verification gate** — affected tests, browser journeys, visual/accessibility,
   security, performance and restart/recovery checks run as applicable.
7. **Independent review gate** — a fresh context reviews the integrated result against
   scope and evidence, not the implementer's summary.
8. **Delivery gate** — clean-environment install, startup, configuration, health,
   migration, rollback and user handoff are verified for the agreed target.

Required gates cannot be waived silently. A check that did not run is `UNVERIFIED`,
not `PASS`. The CTO may ship a staged or blocked result only when it labels the state,
remaining work and exact blocker.
