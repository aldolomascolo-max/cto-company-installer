# Specialist ownership and real skill loading

These are stable project roles, not promises of human experience or permanent
processes. The roster is recorded in `.cto-company/team.md`; the CTO assigns only
needed roles to actual agent sessions. Resolve skill names from the
current catalog and read the chosen SKILL.md before applying it. Bundled skills are
sibling directories beside `cto-company/`; other skills remain separately installed.

| Role | Skills to read when applicable | Owned result and real verification |
|---|---|---|
| Project manager (PM) | This skill's state/delivery guides; `bmad-sprint-planning`, `bmad-retrospective` | Charter, milestones, resource/risks/issues, coordination, acceptance and closeout |
| Product owner/manager (PO) | `bmad-product-brief`, `bmad-prd`, `bmad-spec`, `bmad-deep-recon` when relevant | User/problem research, product strategy, roadmap, prioritized requirements, metrics and feedback loop |
| Product/architecture | Product coverage here; ready BMAD product/spec/architecture/UX modules | Product map, contracts, decisions, acceptance and dependencies |
| Backend/API | Bundled `api-design-principles`; available stack skill and `api-security` | Actual APIs, validation/errors/idempotency and integration tests |
| Data/consistency | Bundled `postgresql-table-design` only for PostgreSQL; `database-security` and chosen database docs | Constraints/transactions/migrations, concurrency/restarts/ownership and reconciliation |
| UX design | `bmad-ux`; Product Design for research and end-to-end experience | User goals, journey strategy, information architecture, research assumptions and experience acceptance |
| Interaction design (IxD) | Product Design; browser tools; `bmad-ux` experience guidance | Functional logic, page flow, navigation, control behavior, transitions, loading/error/empty states and interaction specification |
| UI design | Product Design visual work; `references/design-resources.md`; optional `sleek-design-mobile-apps`; Figma skills for Figma; `imagegen` for raster assets | Visual system, layout, typography, color, icons, imagery, tokens and asset provenance |
| Game UX (optional) | `bmad-ux`, Product Design and official PixiJS entry skill when the product is a game | Game loop, ceremony, game feel, touch feedback and playability evidence |
| Visual design (optional) | Product Design, Figma, `imagegen`, Sleek and design references | Tokens, visual comparisons, responsive variants and asset provenance |
| PixiJS game frontend (optional) | Official `pixijs` skill family, `playwright` and runtime inspection | Canvas scenes, input, assets, animation, FPS/memory and resize evidence |
| Mobile experience (optional) | `playwright`, Product Design audit, accessibility and Sleek when connected | Viewport/device screenshots, touch/safe-area/keyboard checks and runtime evidence |
| Frontend/accessibility | Bundled `accessibility-compliance`; relevant frontend skills; `playwright`/browser tools | Responsive working journeys, keyboard/focus, screenshots and console/network evidence |
| Performance/reliability | [Reliability checks](delivery.md#reliability-and-data-checks); actual stack/profiler/load tools; data skill where relevant | Workload, measured latency/throughput/resources and recovery; no estimates sold as measurements |
| Security | `code-audit`, `api-security`, `database-security`; available `supply-chain-security`/`cloud-k8s` only when relevant | App-specific threats, boundaries and verified fixes, no unrelated offensive work |
| QA/independent reviewer | Bundled `e2e-testing-patterns`; `playwright`/browser; relevant installed review skills | Tests tied to requirements, missing flows, negative cases, findings and retest evidence |
| Visual/game QA (optional) | `product-design:audit`, `playwright`, `pixijs-performance`, accessibility | Visual regression, interaction/state/performance findings and retest evidence |
| Release/operations | Bundled `deployment-pipeline-design`; actual target's hosting skill | Build/start/setup, health/migration/rollback/recovery and target verification |
| Python automation (optional) | Verified route: `playwright`, `bmad-build` and project runner; `cto-company:python-automation` is a workflow-only wrapper | Reproducible scripts, batch/import/export checks and failure handling |
| BI/analytics (optional) | Verified route: `spreadsheets`, `visualize` and project SQL; `cto-company:bi-analytics` is a workflow-only wrapper | Metric definitions, reproducible queries/aggregations and validated reports |
| Data engineering (optional) | Verified route: database/schema/security skills and existing job tooling; `cto-company:data-engineering` is a workflow-only wrapper | Lineage, ETL/ELT, idempotency, data quality and recovery evidence |
| LLM application engineering (optional) | Verified route: Agents SDK, OpenAI API/docs and `llm-security`; `cto-company:llm-application-engineering` is a workflow-only wrapper | Real model/tool traces, evals, safety, cost/latency and fallback evidence |
| Cloud/DevOps (optional) | Verified route: deployment, Netlify/Sites/cloud skills; `cto-company:cloud-devops` is a workflow-only wrapper | Repeatable build, environment, health, observability, rollback and recovery evidence |
| Web reasoning reviewer (optional) | `codex-bridge-chatgpt` only after explicit risk consent and browser/model preflight; local Codex remains the executor | Bounded sanitized packet, validated untrusted result, local adoption decisions and run receipt |

Each worker packet names selected skills, owned files, contracts, checks, tools and
dependencies; “use relevant skills” alone is insufficient. Require actual tool-use
evidence. For a stack without a matching skill, use its official docs and state the
limitation rather than forcing a different framework or database.

## Memory and resumption

At the start of a task, read `.cto-company/state.md`, `.cto-company/team.md` and the
latest lines of `.cto-company/events.ndjson`. At every material phase change, append
one event and update the state with observed evidence, not a hopeful summary. Keep
secrets, credentials and personal data out of these files. This state lets a later
Codex task resume; it does not make a stopped Codex process continue in the background.

## Existing orchestrators and wrappers

- Native mode is the default: Codex lead uses real subagent tools and current model
  settings, with no extra daemon.
- BMAD: the official `bmad-method` and `bmad-toolbox` plugins are installed. For a
  project without `_bmad/scripts/render_skill.py`, invoke the installed `bmad` skill
  with `bmad setup`; it owns setup questions and writes. Never hand-create `_bmad`,
  invoke a broken wrapper, or bypass setup by executing hidden workflow sources. If
  setup is unavailable or fails, use this self-contained CTO workflow, record the
  concrete gap and do not claim BMAD ran.
- Astral remains available when explicitly selected. Read its skill and pass its
  model/effort preflight. Do not change global models or claim Astral ran without
  evidence. Native mode is separate, not a silent fallback after an exact-route failure.
- 总指挥 may discover specialists inside its assignment; the CTO retains product
  ownership. Avoid a second whole-project planning process.
- Ponytail reduces complexity, not agreed product completeness, protections,
  accessibility or acceptance. A working slice is not permission to stop early.

Bundled MIT packages are pinned in the plugin-root `THIRD_PARTY.md`. Examples,
libraries, app modules and CI helpers are not installed automatically. Reuse the
project stack/auth/migrations/test runner; verify examples against current docs.
Do not add layers or frameworks merely because examples use them. CI references to
Slack or deployment do not authorize messages or publishing. Sample transactions do
not establish tenant isolation, accounting correctness or retry safety.
