#!/usr/bin/env python3
"""Create the small, durable state surface used by cto-company.

This only writes inside the selected project: `.cto-company/` and a marked
section in the project's AGENTS.md. It does not install dependencies, run
commands, start services, or overwrite existing project instructions.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import sys


MARKER_START = "<!-- BEGIN cto-company project -->"
MARKER_END = "<!-- END cto-company project -->"

PROJECT_RULES = f"""{MARKER_START}
## AI software company project state

Use the installed `cto-company:cto-company` skill as the single product lead for
complete-product work. Read `.cto-company/state.md` and `.cto-company/team.md`
before planning. Keep the state current after material decisions, verification,
handoffs, blockers, and resumable next actions. Do not call a prototype or an
unverified preview complete. Preserve this project's existing instructions,
secrets, scope, and approval boundaries.
{MARKER_END}
"""

STATE_TEMPLATE = """# CTO project state

status: initialized
last_updated: {timestamp}
project: {project}

## Product intent

<!-- CTO records the user's agreed product intent and explicit non-goals here. -->

## Current phase

intake

## Decisions

<!-- One decision per bullet: date — decision — reason — approver. -->

## Acceptance and evidence

<!-- Link or path to the current acceptance map, commands, screenshots and reports. -->

## Active work

<!-- task | owner | status | dependency | evidence -->

## Blockers and user decisions

<!-- Keep only unresolved items that really require the user or external access. -->

## Next resumable action

Read this file, verify current artifacts, then continue from the active work list.
"""

TEAM_TEMPLATE = """# CTO project team roster

The CTO is the single accountable lead. Roles are activated only when the product
needs them; a role is a responsibility and evidence contract, not a claim of human
employment history.

| Role | Responsibility | Required evidence |
|---|---|---|
| Project manager (PM) | Delivery plan, milestones, resources, risks, issues and acceptance | Charter, milestone plan, risk/issues log and closeout |
| Product owner/manager (PO) | Users, product value, roadmap, priority and feedback | Product brief/PRD, prioritized backlog and product acceptance |
| Product lead | Intent, scope, journeys, acceptance | Approved product map and gaps |
| Architect | Boundaries, contracts, dependencies | Architecture decisions and interface checks |
| UX designer | User goals, journey strategy, research assumptions, information architecture | Experience map, journey decisions, UX acceptance |
| Interaction designer (IxD) | Functional logic, page flow, control behavior, transitions and states | Interaction specification and flow/state checks |
| UI designer | Visual system, layout, typography, color, icons and assets | Screenshots, tokens, asset provenance |
| Frontend | Responsive user journeys and accessibility | Browser checks, console/network evidence |
| Backend/API | Business behavior, validation, failures | API/integration checks and durable state |
| Data/reliability | Constraints, concurrency, migration/recovery | Invariant and recovery evidence |
| Security | Trust boundaries, auth, secrets, tenant isolation | Findings and verified fixes |
| QA/reviewer | Independent completeness and regression review | Fresh review, findings, retest |
| Release/SRE | Build, health, observability, rollback | Target-specific release evidence |

The CTO assigns exact ownership, selected skills, tools and checks per task. Workers
must report changes, commands/results, decisions and remaining gaps. The roster is
stable; active assignments belong in `state.md`.
"""


def atomic_write(path: Path, content: str) -> None:
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.write_text(content, encoding="utf-8")
    temporary.replace(path)


def append_rules(path: Path) -> bool:
    existing = path.read_text(encoding="utf-8") if path.exists() else ""
    if MARKER_START in existing or MARKER_END in existing:
        if MARKER_START not in existing or MARKER_END not in existing:
            raise ValueError("AGENTS.md has an incomplete cto-company project block")
        return False
    separator = "\n" if existing and not existing.endswith("\n") else ""
    atomic_write(path, existing + separator + "\n" + PROJECT_RULES)
    return True


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", required=True, type=Path)
    parser.add_argument("--event", help="Append one durable event to events.ndjson")
    parser.add_argument("--owner", default="cto", help="Owner for --event")
    args = parser.parse_args()

    project = args.project.expanduser()
    if not project.is_absolute() or not project.is_dir():
        parser.error("--project must be an existing absolute directory")
    project = project.resolve()
    state_dir = project / ".cto-company"
    state_dir.mkdir(exist_ok=True)
    state = state_dir / "state.md"
    team = state_dir / "team.md"
    events = state_dir / "events.ndjson"
    timestamp = datetime.now(timezone.utc).isoformat()
    created = []
    if not state.exists():
        atomic_write(state, STATE_TEMPLATE.format(timestamp=timestamp, project=project))
        created.append(str(state))
    if not team.exists():
        atomic_write(team, TEAM_TEMPLATE)
        created.append(str(team))
    if not events.exists():
        atomic_write(events, "")
        created.append(str(events))
    rules_added = append_rules(project / "AGENTS.md")
    if args.event:
        with events.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps({"timestamp": timestamp, "owner": args.owner, "event": args.event}, ensure_ascii=False) + "\n")
    bmad_ready = (project / "_bmad" / "scripts" / "render_skill.py").is_file()
    print(json.dumps({
        "project": str(project),
        "state_dir": str(state_dir),
        "created": created,
        "agents_rules_added": rules_added,
        "bmad_runtime": "ready" if bmad_ready else "setup-required",
        "event_recorded": bool(args.event),
    }, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError) as error:
        print(f"bootstrap_project: {error}", file=sys.stderr)
        raise SystemExit(2)
