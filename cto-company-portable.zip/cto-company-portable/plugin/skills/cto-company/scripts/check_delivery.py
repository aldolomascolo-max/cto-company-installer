#!/usr/bin/env python3
"""Run trusted local commands from an acceptance manifest and record evidence.

The manifest is trusted local command input, not an authorization mechanism.
Passing checks does not replace independent UI, security, or manual review.
POSIX timeouts and cancellation terminate the command's process group; other platforms terminate
only the direct child. Processes that deliberately detach need external isolation.
Exit code 2 leaves any previous report untouched; ignore that report for this run.
SIGINT/SIGTERM cancellation exits 130/143; ignore previous reports after cancellation.
"""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time


def load_checks(project, manifest, output):
    if not project.is_absolute() or not project.is_dir():
        raise ValueError("project must be an existing absolute directory")
    project = project.resolve()
    if output.resolve() == manifest.resolve() or (
        output.exists() and manifest.exists() and output.samefile(manifest)
    ):
        raise ValueError("output must not overwrite the manifest")
    if not output.parent.is_dir() or output.is_dir():
        raise ValueError("output must be a file in an existing directory")
    raw = manifest.read_bytes()
    data = json.loads(raw.decode("utf-8"))
    if not isinstance(data, dict) or type(data.get("schema_version")) is not int or data["schema_version"] != 1:
        raise ValueError("manifest must be an object with schema_version 1")
    checks = data.get("checks")
    if not isinstance(checks, list) or not checks:
        raise ValueError("manifest checks must be a nonempty list")
    validated = []
    seen = set()
    for index, check in enumerate(checks):
        label = f"check {index + 1}"
        if not isinstance(check, dict):
            raise ValueError(f"{label} must be an object")
        check_id = check.get("id")
        if not isinstance(check_id, str) or not check_id.strip() or check_id in seen:
            raise ValueError(f"{label} must have a unique nonempty id")
        seen.add(check_id)
        argv = check.get("argv")
        if not isinstance(argv, list) or not argv or any(
            not isinstance(arg, str) or "\0" in arg for arg in argv
        ) or not argv[0]:
            raise ValueError(f"{label} argv must be a nonempty string array with an executable")
        cwd = check.get("cwd", ".")
        if not isinstance(cwd, str) or "\0" in cwd or Path(cwd).is_absolute():
            raise ValueError(f"{label} cwd must be relative to the project")
        directory = (project / cwd).resolve()
        if not directory.is_relative_to(project) or not directory.is_dir():
            raise ValueError(f"{label} cwd must be an existing directory inside the project")
        timeout = check.get("timeout_seconds", 120)
        if type(timeout) is not int or not 1 <= timeout <= 3600:
            raise ValueError(f"{label} timeout_seconds must be an integer from 1 to 3600")
        validated.append({"id": check_id, "argv": argv, "cwd": str(directory), "timeout_seconds": timeout})
    return project, hashlib.sha256(raw).hexdigest(), validated


def output_tail(stream):
    # Read enough UTF-8 bytes for the final 8000 characters without loading the log.
    stream.seek(max(0, stream.seek(0, os.SEEK_END) - 32000))
    return stream.read().decode("utf-8", errors="replace")[-8000:]


def terminate_check(process):
    if os.name == "posix":
        try:
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            # Give descendants a grace period even if their parent exits first.
            time.sleep(1)
        finally:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait(timeout=1)
    else:
        # ponytail: direct child only; use platform job isolation for descendant cleanup.
        try:
            process.terminate()
            process.wait(timeout=1)
        except subprocess.TimeoutExpired:
            pass
        finally:
            process.kill()
            process.wait(timeout=1)


def run_check(check):
    started = time.monotonic()
    result = dict(check, status="failed", exit_code=None)
    with tempfile.TemporaryFile() as stdout, tempfile.TemporaryFile() as stderr:
        process = None
        try:
            process = subprocess.Popen(
                check["argv"], cwd=check["cwd"], shell=False,
                stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                start_new_session=os.name == "posix",
            )
            result["exit_code"] = process.wait(timeout=check["timeout_seconds"])
            if result["exit_code"] == 0:
                result["status"] = "passed"
        except subprocess.TimeoutExpired:
            result["error"] = f"timed out after {check['timeout_seconds']} seconds"
        except OSError as error:
            result["error"] = str(error)
        finally:
            if process is not None and result["exit_code"] is None:
                try:
                    terminate_check(process)
                except (OSError, subprocess.TimeoutExpired) as error:
                    result["error"] = f"{result.get('error', 'cancelled')}; cleanup failed: {error}"
                    print(f"check_delivery: cleanup failed: {error}", file=sys.stderr)
        result.update(stdout=output_tail(stdout), stderr=output_tail(stderr))
    result["duration_seconds"] = round(time.monotonic() - started, 3)
    return result


def write_report(output, report):
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=output.parent, delete=False) as stream:
            temporary = Path(stream.name)
            json.dump(report, stream, indent=2, ensure_ascii=True)
            stream.write("\n")
        os.replace(temporary, output)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def cancel_run(signum, _frame):
    # A second cancellation must not interrupt the bounded cleanup already underway.
    signal.signal(signal.SIGINT, signal.SIG_IGN)
    signal.signal(signal.SIGTERM, signal.SIG_IGN)
    raise KeyboardInterrupt(signum)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", required=True, type=Path)
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    try:
        signal.signal(signal.SIGINT, cancel_run)
        signal.signal(signal.SIGTERM, cancel_run)
        project, manifest_hash, checks = load_checks(args.project, args.manifest, args.output)
        report = {
            "schema_version": 1,
            "project": str(project),
            "manifest_sha256": manifest_hash,
            "started_at": datetime.now(timezone.utc).isoformat(),
        }
        report["results"] = [run_check(check) for check in checks]
        passed = all(result["status"] == "passed" for result in report["results"])
        report["status"] = "automated_checks_passed" if passed else "failed"
        write_report(args.output, report)
    except KeyboardInterrupt as error:
        signum = error.args[0] if error.args else signal.SIGINT
        print(f"check_delivery: cancelled by {signal.Signals(signum).name}; "
              "ignore any existing output report for this run.", file=sys.stderr)
        return 128 + signum
    except (OSError, ValueError, RuntimeError) as error:
        print(f"check_delivery: {error}", file=sys.stderr)
        print("Exit 2: ignore any existing output report for this run.", file=sys.stderr)
        return 2
    print(f"{report['status']}: {args.output}")
    return 0 if passed else 1


if __name__ == "__main__":
    sys.exit(main())
