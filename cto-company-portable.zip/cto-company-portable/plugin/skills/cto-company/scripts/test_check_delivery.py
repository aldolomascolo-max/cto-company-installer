"""Local CLI checks; run with: python3 test_check_delivery.py

Fixtures are trusted local command input. They do not authorize operations or
replace independent UI, security, or manual review of a delivered project.
"""

import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
import unittest


RUNNER = Path(__file__).with_name("check_delivery.py")


class DeliveryChecks(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.project = self.root / "project"
        self.project.mkdir()
        self.manifest = self.root / "acceptance.json"
        self.output = self.root / "results.json"

    def check(self, check_id="example", code="print('ok')", **extra):
        return {"id": check_id, "argv": [sys.executable, "-c", code], **extra}

    def run_manifest(self, checks, output=None):
        self.manifest.write_text(json.dumps({"schema_version": 1, "checks": checks}), encoding="utf-8")
        return self.run_cli(output)

    def run_cli(self, output=None):
        completed = subprocess.run(
            [sys.executable, str(RUNNER), "--project", str(self.project),
             "--manifest", str(self.manifest), "--output", str(output or self.output)],
            capture_output=True, text=True, timeout=10,
        )
        self.assertNotIn("Traceback", completed.stderr)
        return completed

    def report(self):
        return json.loads(self.output.read_text(encoding="utf-8"))

    def test_success_output_bound_and_metadata(self):
        (self.project / "child").mkdir()
        check = self.check(code="import sys; print('x' * 9000); print('warning', file=sys.stderr)", cwd="child")
        self.output.write_text("previous report", encoding="utf-8")
        completed = self.run_manifest([check])
        self.assertEqual(completed.returncode, 0, completed.stderr)
        report = self.report()
        self.assertEqual(report["schema_version"], 1)
        self.assertEqual(report["status"], "automated_checks_passed")
        self.assertEqual(report["project"], str(self.project.resolve()))
        self.assertEqual(report["manifest_sha256"], hashlib.sha256(self.manifest.read_bytes()).hexdigest())
        self.assertTrue(report["started_at"].endswith("+00:00"))
        result = report["results"][0]
        self.assertEqual(result["argv"], check["argv"])
        self.assertEqual(result["cwd"], str((self.project / "child").resolve()))
        self.assertEqual(result["exit_code"], 0)
        self.assertEqual(result["status"], "passed")
        self.assertGreaterEqual(result["duration_seconds"], 0)
        self.assertEqual(result["timeout_seconds"], 120)
        self.assertEqual(len(result["stdout"]), 8000)
        self.assertEqual(result["stderr"], "warning\n")

    def test_nonzero_runs_remaining_check_once(self):
        checks = [self.check("bad", "import sys; print('failure', file=sys.stderr); sys.exit(7)"),
                  self.check("next", "from pathlib import Path; p=Path('count'); p.write_text(p.read_text()+'x' if p.exists() else 'x')")]
        self.assertEqual(self.run_manifest(checks).returncode, 1)
        report = self.report()
        self.assertEqual(report["status"], "failed")
        self.assertEqual([result["exit_code"] for result in report["results"]], [7, 0])
        self.assertEqual(report["results"][0]["stderr"], "failure\n")
        self.assertEqual((self.project / "count").read_text(), "x")

    def test_invalid_checks_rejected_before_execution(self):
        marker = self.check("marker", "from pathlib import Path; Path('executed').touch()")
        invalid_lists = [[], [marker, marker], [marker, {}], [marker, {"id": "no-argv"}],
                         [marker, self.check("bad", timeout_seconds=0)],
                         [marker, self.check("bad", timeout_seconds=3601)],
                         [marker, self.check("bad", timeout_seconds=True)],
                         [marker, self.check("bad", argv=[])],
                         [marker, self.check("bad", argv=[42])]]
        for checks in invalid_lists:
            with self.subTest(checks=checks):
                self.assertEqual(self.run_manifest(checks).returncode, 2)
                self.assertFalse((self.project / "executed").exists())
                self.assertFalse(self.output.exists())

    def test_malformed_or_empty_manifest(self):
        for content in ["", "{", "[]", "{}", '{"schema_version": true, "checks": []}',
                        '{"schema_version": 1, "checks": null}']:
            with self.subTest(content=content):
                self.manifest.write_text(content, encoding="utf-8")
                self.assertEqual(self.run_cli().returncode, 2)
                self.assertFalse(self.output.exists())

    def test_missing_project(self):
        self.project.rmdir()
        self.assertEqual(self.run_manifest([self.check()]).returncode, 2)
        self.assertFalse(self.output.exists())

    def test_path_escape_rejected_before_execution(self):
        marker = self.check("marker", "from pathlib import Path; Path('executed').touch()")
        for cwd in ["..", str(self.root), "missing"]:
            with self.subTest(cwd=cwd):
                self.assertEqual(self.run_manifest([marker, self.check("bad", cwd=cwd)]).returncode, 2)
                self.assertFalse((self.project / "executed").exists())

    def test_symlink_escape(self):
        try:
            (self.project / "outside").symlink_to(self.root, target_is_directory=True)
        except (OSError, NotImplementedError):
            self.skipTest("directory symlinks unavailable")
        self.assertEqual(self.run_manifest([self.check(cwd="outside")]).returncode, 2)
        self.assertFalse(self.output.exists())

    def test_missing_command(self):
        missing = self.check(argv=[str(self.root / "command-that-does-not-exist")])
        self.assertEqual(self.run_manifest([missing]).returncode, 1)
        result = self.report()["results"][0]
        self.assertEqual(result["status"], "failed")
        self.assertIsNone(result["exit_code"])
        self.assertIn("error", result)

    def test_timeout_preserves_output(self):
        check = self.check(code="import time; print('started', flush=True); time.sleep(5)", timeout_seconds=1)
        self.assertEqual(self.run_manifest([check]).returncode, 1)
        result = self.report()["results"][0]
        self.assertEqual(result["status"], "failed")
        self.assertIsNone(result["exit_code"])
        self.assertIn("timed out", result["error"])
        self.assertEqual(result["stdout"], "started\n")
        self.assertLess(result["duration_seconds"], 4)

    @unittest.skipUnless(os.name == "posix", "process groups require POSIX")
    def test_timeout_kills_descendant_that_ignores_termination(self):
        child = (
            "import signal, time; from pathlib import Path; "
            "signal.signal(signal.SIGTERM, signal.SIG_IGN); "
            "Path('child-ready').touch(); time.sleep(3); Path('delayed-marker').touch()"
        )
        parent = f"import subprocess, sys, time; subprocess.Popen([sys.executable, '-c', {child!r}]); time.sleep(10)"
        started = time.monotonic()
        self.assertEqual(self.run_manifest([self.check(code=parent, timeout_seconds=1)]).returncode, 1)
        self.assertTrue((self.project / "child-ready").exists())
        self.assertLess(self.report()["results"][0]["duration_seconds"], 4)
        time.sleep(max(0, 4 - (time.monotonic() - started)))
        self.assertFalse((self.project / "delayed-marker").exists())

    def check_cancellation(self, sig):
        child = (
            "import os, signal, time; from pathlib import Path; "
            "signal.signal(signal.SIGTERM, signal.SIG_IGN); "
            "Path('child-ready').write_text(str(os.getpgrp())); "
            "time.sleep(2); Path('delayed-marker').touch()"
        )
        parent = f"import subprocess, sys, time; subprocess.Popen([sys.executable, '-c', {child!r}]); time.sleep(10)"
        checks = [self.check(code=parent, timeout_seconds=10),
                  self.check("next", "from pathlib import Path; Path('next-check').touch()")]
        self.manifest.write_text(json.dumps({"schema_version": 1, "checks": checks}), encoding="utf-8")
        self.output.write_text("previous report", encoding="utf-8")
        runner = subprocess.Popen(
            [sys.executable, str(RUNNER), "--project", str(self.project),
             "--manifest", str(self.manifest), "--output", str(self.output)],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
        )
        ready = self.project / "child-ready"
        try:
            deadline = time.monotonic() + 5
            while not ready.exists() and runner.poll() is None and time.monotonic() < deadline:
                time.sleep(0.02)
            self.assertTrue(ready.exists(), "descendant did not become ready")
            started = time.monotonic()
            runner.send_signal(sig)
            stdout, stderr = runner.communicate(timeout=5)
            self.assertEqual(runner.returncode, 128 + sig, stderr)
            self.assertIn(f"cancelled by {sig.name}", stderr)
            self.assertIn("ignore any existing output report", stderr)
            self.assertNotIn("Traceback", stderr)
            self.assertNotIn("automated_checks_passed", stdout)
            self.assertLess(time.monotonic() - started, 4)
            time.sleep(max(0, 3 - (time.monotonic() - started)))
            self.assertFalse((self.project / "delayed-marker").exists())
            self.assertFalse((self.project / "next-check").exists())
            self.assertEqual(self.output.read_text(encoding="utf-8"), "previous report")
        finally:
            if runner.poll() is None:
                runner.kill()
            runner.communicate(timeout=5)
            if ready.exists():
                try:
                    os.killpg(int(ready.read_text()), signal.SIGKILL)
                except ProcessLookupError:
                    pass

    @unittest.skipUnless(os.name == "posix", "process group cancellation requires POSIX")
    def test_sigint_cleans_up_descendants(self):
        self.check_cancellation(signal.SIGINT)

    @unittest.skipUnless(os.name == "posix", "process group cancellation requires POSIX")
    def test_sigterm_cleans_up_descendants(self):
        self.check_cancellation(signal.SIGTERM)

    def test_output_manifest_collision(self):
        checks = [self.check(code="from pathlib import Path; Path('executed').touch()")]
        self.assertEqual(self.run_manifest(checks, output=self.manifest).returncode, 2)
        self.assertEqual(json.loads(self.manifest.read_text())["checks"], checks)
        self.assertFalse((self.project / "executed").exists())

    def test_output_manifest_alias_collision(self):
        checks = [self.check(code="from pathlib import Path; Path('executed').touch()")]
        self.manifest.write_text("placeholder", encoding="utf-8")
        for link_type in ["symlink", "hardlink"]:
            with self.subTest(link_type=link_type):
                alias = self.root / link_type
                try:
                    if link_type == "symlink":
                        alias.symlink_to(self.manifest)
                    else:
                        os.link(self.manifest, alias)
                except (OSError, NotImplementedError):
                    continue
                self.assertEqual(self.run_manifest(checks, output=alias).returncode, 2)
                self.assertEqual(json.loads(self.manifest.read_text())["checks"], checks)
                self.assertFalse((self.project / "executed").exists())

    def test_output_error(self):
        self.assertEqual(self.run_manifest([self.check()], output=self.root / "missing" / "results.json").returncode, 2)
        self.assertFalse(self.output.exists())

    def test_invalid_run_preserves_previous_report_with_warning(self):
        self.output.write_text("previous report", encoding="utf-8")
        completed = self.run_manifest([])
        self.assertEqual(completed.returncode, 2)
        self.assertIn("ignore any existing output report", completed.stderr)
        self.assertEqual(self.output.read_text(encoding="utf-8"), "previous report")


if __name__ == "__main__":
    unittest.main()
