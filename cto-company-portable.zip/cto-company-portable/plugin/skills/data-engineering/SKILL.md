---
name: data-engineering
description: Design and verify ETL/ELT, event pipelines, lineage, data quality, replay, and recovery for products that move or scale data across systems. Do not add a data platform when the product does not need one.
---

# Data Engineering

This is a workflow-only wrapper, not an ETL platform or managed data infrastructure. Use verified project database and job tooling first.

Activate when the capability plan identifies cross-system data movement, growing volume, event
processing, warehouse/lake needs or scheduled backfills.

1. Inventory sources, owners, schemas, contracts, retention, sensitivity, volume, latency and
   failure boundaries. Draw the actual lineage from source to durable destination and consumer.
2. Define idempotency, ordering, deduplication, checkpointing, replay, late-arriving data,
   backfill and migration behavior before implementing jobs. Reuse the existing database and
   job runner unless measurements justify a new platform.
3. Add data-quality checks for completeness, uniqueness, validity, freshness and reconciliation.
   Keep credentials out of code and logs; apply least privilege and retention limits.
4. Run a representative fixture plus failure/replay checks. Report throughput and recovery
   measurements, schema changes, evidence paths and the scale ceiling. A pipeline design or
   green unit test alone does not prove durable data delivery.
