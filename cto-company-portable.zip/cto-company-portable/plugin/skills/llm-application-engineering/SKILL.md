---
name: llm-application-engineering
description: Build and evaluate AI product features such as model calls, RAG, tool use, agents, safety, cost, latency, and fallbacks when the product actually contains an LLM capability.
---

# Llm Application Engineering

This is a workflow-only wrapper, not a model provider, evaluation platform, or agent runtime. Use the verified provider and Agents SDK skills first.

Activate only when the product map includes an AI or model-backed behavior.

1. Define the user task, input/output schema, model/provider boundary, source grounding, tool
   permissions, refusal behavior, latency and cost budget. Keep API keys in the approved secret
   store and never write them to project files or logs.
2. Use the available provider documentation and Agents SDK when applicable. Keep application
   logic deterministic around the model: validate inputs/outputs, bound tool calls, enforce
   authorization, redact sensitive data and provide a useful fallback when the model/provider
   is unavailable.
3. For RAG, record source provenance, chunk/retrieval rules, freshness and citation behavior.
   For agents, record tool schemas, side effects, approval boundaries and stop conditions.
4. Create a small representative evaluation set covering correctness, refusal, injection,
   grounding, latency, cost and failure recovery. Run it and report observed results; prompts or
   a mock response are not evidence of a working AI feature.
